import os
command_to_exec = 'python ' + '"' +  os.path.join(os.path.dirname(os.path.abspath(__file__)), "main.pyc") + '"'
os.system(command_to_exec)
